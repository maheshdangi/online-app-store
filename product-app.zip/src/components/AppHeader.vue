<template>
  <header style="background:white; border-bottom:1px solid #ddd; padding:8px 16px; display:flex; align-items:center; justify-content:space-between;">
    <div style="display:flex; align-items:center; gap:12px;">
      <a @click.prevent="goHome" href="/products" style="display:flex; align-items:center; gap:8px; text-decoration:none;">
        <img src="/src/assets/logo.png" alt="logo" style="height:34px;"/>
        <strong style="color:#0aa; font-size:18px;">BÜHLER</strong>
      </a>
      <div style="color:#666;">{{ nowString }}</div>
    </div>
    <div>
      <a @click.prevent="goCheckout" href="/checkout" style="text-decoration:none; color:#0aa;">
        Cart ({{ cartCount }})
      </a>
    </div>
  </header>
</template>

<script lang="ts">
import { defineComponent, ref, onMounted, onUnmounted } from 'vue'
import { useCart } from '../stores/cart'

export default defineComponent({
  setup() {
    const { count } = useCart()
    const cartCount = count
    const now = ref(new Date())
    const tick = () => now.value = new Date()
    let id: number
    onMounted(() => {
      id = window.setInterval(tick, 1000)
    })
    onUnmounted(() => {
      clearInterval(id)
    })
    const nowString = computed(() => now.value.toLocaleString())
    function goHome() { window.location.href = '/products' }
    function goCheckout() { window.location.href = '/checkout' }
    return { cartCount, nowString, goHome, goCheckout }
  }
})
</script>

<style scoped>
a { cursor: pointer; }
</style>
