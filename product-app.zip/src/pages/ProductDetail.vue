<template>
  <div v-if="product">
    <button @click="goBack" style="margin-bottom:12px;">← Back</button>
    <div style="display:flex; gap:16px; background:white; padding:12px; border-radius:6px;">
      <img :src="product.image" alt="" style="width:320px; height:220px; object-fit:cover; background:#eee;" />
      <div>
        <h2>{{ product.name }}</h2>
        <div>Type: {{ product.type }}</div>
        <div style="margin:8px 0; font-weight:700;">Price: x{{ product.price.toFixed(2) }}</div>
        <button @click="addToCart">Add to Cart</button>
      </div>
    </div>
  </div>
  <div v-else>
    <p>Product not found</p>
    <button @click="goBack">Back to list</button>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import productsData from '../data/products.json'
import { useRoute, useRouter } from 'vue-router'
import { useCart } from '../stores/cart'

export default defineComponent({
  setup(){
    const route = useRoute()
    const router = useRouter()
    const { add } = useCart()
    const id = route.params.id as string
    // find product in data
    let product = null
    for (const s of (productsData as any).sections){
      const found = s.products.find((p:any)=>p.id === id)
      if (found) { product = found; break }
    }
    function goBack(){ router.push('/products') }
    function addToCart(){
      if (product) {
        add({ id: product.id, name: product.name, price: product.price, image: product.image, type: product.type })
        alert('Added to cart')
      }
    }
    return { product, goBack, addToCart }
  }
})
</script>
