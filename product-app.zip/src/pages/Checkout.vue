<template>
  <div>
    <h2>Checkout</h2>
    <div v-if="items.length === 0">Cart is empty</div>
    <table v-else style="width:100%; border-collapse:collapse; background:white;">
      <thead><tr><th style="text-align:left; padding:8px;">Product</th><th>Price</th><th></th></tr></thead>
      <tbody>
        <tr v-for="(it, idx) in items" :key="idx" style="border-top:1px solid #eee;">
          <td style="padding:8px; display:flex; gap:8px; align-items:center;">
            <img :src="it.image" alt="" style="width:80px; height:60px; object-fit:cover; background:#eee;" />
            <div>
              <div style="font-weight:600;">{{ it.name }}</div>
              <div style="color:#666;">{{ it.type }}</div>
            </div>
          </td>
          <td style="text-align:center;">x{{ it.price.toFixed(2) }}</td>
          <td style="text-align:center;"><button @click="remove(idx)">Remove</button></td>
        </tr>
      </tbody>
      <tfoot>
        <tr><td style="padding:12px; font-weight:700;">Total</td><td style="font-weight:700; text-align:center;">x{{ total.toFixed(2) }}</td><td></td></tr>
      </tfoot>
    </table>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import { useCart } from '../stores/cart'

export default defineComponent({
  setup(){
    const { items, remove, total } = useCart()
    return { items, remove, total }
  }
})
</script>
