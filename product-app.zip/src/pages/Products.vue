<template>
  <div>
    <section v-for="section in data.sections" :key="section.id" style="margin-bottom:24px;">
      <h3>{{ section.title }}</h3>
      <div style="display:grid; grid-template-columns: repeat(auto-fill,minmax(220px,1fr)); gap:12px;">
        <ProductCard v-for="p in section.products" :key="p.id" :product="p" />
      </div>
    </section>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue'
import ProductCard from '../components/ProductCard.vue'
import data from '../data/products.json'

export default defineComponent({
  components: { ProductCard },
  setup(){
    const dt = data as any
    return { data: dt }
  }
})
</script>
